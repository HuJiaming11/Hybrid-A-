#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/thomas/lessen_shelan/chapter_4/homework/src/grid_path_searcher/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/thomas/lessen_shelan/chapter_4/homework/src/grid_path_searcher/cmake-build-debug/devel/lib:/home/thomas/lessen_shelan/chapter_4/homework/devel/lib:/opt/ros/kinetic/lib:/opt/ros/kinetic/lib/x86_64-linux-gnu:/home/thomas/software_installed/clion-2017.2.3/bin:/usr/local/lib"
export PKG_CONFIG_PATH="/home/thomas/lessen_shelan/chapter_4/homework/src/grid_path_searcher/cmake-build-debug/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/thomas/lessen_shelan/chapter_4/homework/src/grid_path_searcher/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/thomas/lessen_shelan/chapter_4/homework/src/grid_path_searcher:$ROS_PACKAGE_PATH"